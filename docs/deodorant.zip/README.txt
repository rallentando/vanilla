Deodorant -- what was stripped from this published tree.

deodorant.diff is the unified diff of every published file against
its private original: the comments of the C++, JavaScript and CSS
sources (stripped wholesale, save the '//#define' build toggles),
runs of blank lines, debug prints and debug-only blocks.
Apply it in reverse to restore them.

'D-nnn', seen in the docs and the removed comments, numbers the entries
of an internal decision log which is not published. The log, the
working logs and the roadmap stay private, and are not in this diff
either.
（本文や注釈に現れる D-nnn は、非公開の内部決定ログの項番です。
そのログ自体はこの diff にも含まれていません。）
